import pandas as pd
from scipy.signal import find_peaks
import tkinter as tk
from tkinter import filedialog
import os
from openpyxl import load_workbook
from openpyxl.styles import Alignment

# Function to select a file
def select_file(title, filetypes):
    root = tk.Tk()
    root.withdraw()  # Hide the root window
    file_path = filedialog.askopenfilename(title=title, filetypes=filetypes)
    return file_path

# Function to save the results to an XLSX file with incremental filenames in the same folder as the original
def save_results(merged_data, original_filepath):
    base_name = os.path.splitext(os.path.basename(original_filepath))[0]
    folder_path = os.path.dirname(original_filepath)
    counter = 1
    while True:
        save_path = os.path.join(folder_path, f"{base_name}_gmcode{counter}.xlsx")
        if not os.path.exists(save_path):
            break
        counter += 1
    
    merged_data.to_excel(save_path, index=False)
    print(f"Results saved to {save_path}")

# Main function to analyze the accelerometer data for vibration signal in machining process
def analyze_vibration_signal():
    # Select the Excel file
    file_path = select_file("Select an Excel file", [("Excel files", "*.xlsx")])
    
    if not file_path:
        print("No file selected.")
        return
    
    # Load the Excel file
    data = pd.read_excel(file_path)

    # Find peaks in the ACC_X, ACC_Y, and ACC_Z columns
    peaks_x, _ = find_peaks(data['ACC_X'])
    peaks_y, _ = find_peaks(data['ACC_Y'])
    peaks_z, _ = find_peaks(data['ACC_Z'])

    # Create a new column 'Peaks' to indicate where peaks occur
    data['Peaks'] = 0
    data.loc[peaks_x, 'Peaks'] = 1
    data.loc[peaks_y, 'Peaks'] = 1
    data.loc[peaks_z, 'Peaks'] = 1

    # Define G-code lines with corresponding timestamps
    gcode_lines = [
        "N20 G42 G1 X17. F.2",
        "N22 X15.",
        "N24 X-0.765 Z-0.449",
        "N26 X-0.8 Z-0.448",
        "N28 Z0.052",
        "N30 G0  X17.8",
        "N32 Z-2.",
        "N34  G1 X17.",
        "N36 X15.",
        "N38 X-0.8 Z-1.448",
        "N40 X-0.783 Z-0.949",
        "N42 G0  X41.509 Z21.653",
        "N44 X14.167 Z0.829",
        "N46 G1 G42 Z0.029",
        "N48 Z-41.971",
        "N50 X15. Z-42.",
        "N52 X15.566 Z-41.434",
        "N54 G0  Z0.858",
        "N56 X13.333",
        "N58 G1 Z0.058",
        "N60 Z-41.942",
        "N62 X14.167 Z-41.971",
        "N64 X14.732 Z-41.405",
        "N66 G0  Z0.887",
        "N68 X12.5",
        "N70  G1 Z0.087",
        "N72 Z-41.913",
        "N74 X13.333 Z-41.942",
        "N76 X13.899 Z-41.376",
        "N78 G0  Z0.916",
        "N80 X11.667",
        "N82 G1 Z0.116",
        "N84 Z-41.884",
        "N86 X12.5 Z-41.913",
        "N88 X13.066 Z-41.347",
        "N90 G0  Z0.946",
        "N92 X10.833",
        "N94  G1 Z0.146",
        "N96 Z-41.854",
        "N98 X11.667 Z-41.884",
        "N100 X12.232 Z-41.318",
        "N102 G0  Z0.975",
        "N104 X10.",
        "N106 G1 Z0.175",
        "N108 Z-40.8",
        "N110 G2 X10.613 Z-41.847 R1.2",
        "N112 G1 X10.833 Z-41.854",
        "N114 X11.399 Z-41.289",
        "N116 G0  Z1.004",
        "N118 X9.167",
        "N120 G1 Z0.204"
    ]

    # Create a DataFrame for the G-code lines with corresponding timestamps
    gcode_df = pd.DataFrame({
        'Timestamp': pd.date_range(start='10/15/2024 12:22:28', periods=len(gcode_lines), freq='S'),
        'G-code': gcode_lines
    })

    # Merge the accelerometer data with the G-code DataFrame based on timestamps
    merged_data = pd.merge_asof(data, gcode_df, left_on='_time', right_on='Timestamp', direction='nearest')

    # Filter out rows where the values of ACC_X, ACC_Y, and ACC_Z remain constant (indicating setting process)
    merged_data['Change'] = merged_data[['ACC_X', 'ACC_Y', 'ACC_Z']].diff().abs().sum(axis=1)
    
    # Save the filtered data to a new Excel file including unmatched data
    save_results(merged_data, file_path)

# Run the analysis function
analyze_vibration_signal()
